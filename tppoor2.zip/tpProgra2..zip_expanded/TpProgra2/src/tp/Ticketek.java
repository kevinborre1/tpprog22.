package tp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import tp.Funcion;
import tp.Entrada;
import tp.Espectaculo;
import tp.Estadio;
import tp.Miniestadio;
import tp.Sede;
import tp.Teatro;
import tp.Usuario;


//Cada clase es responsable de asegurar la integridad de sus datos.
//Teniendo eso en cuenta, las validaciones las debería hacer la clase
//y si pasan datos inválidos en el constructor no se debe crear una instancia de esa clase (lanza excepción)



public class Ticketek implements ITicketek {

	HashMap <String,Usuario> Usuarios = new HashMap<>();
	HashMap <String,Sede> Sedes = new HashMap<>();
	HashMap<String, Espectaculo> Espectaculos = new HashMap<>();
	HashMap<String, Entrada> Entradas = new HashMap<>();
	
    
	@Override
    public void registrarSede(String nombre, String direccion, int capacidadMaxima) {
		verificarSede(nombre);
		Sedes.put(nombre,new Estadio(nombre,direccion,capacidadMaxima));
    }
    

	@Override
	public void registrarSede(String nombre, String direccion, int capacidadMaxima, int asientosPorFila,
			String[] sectores, int[] capacidad, int[] porcentajeAdicional) {
		verificarSede(nombre);
		Sedes.put(nombre,new Teatro(nombre,direccion,capacidadMaxima,asientosPorFila,sectores,capacidad,porcentajeAdicional));

	}

	@Override
	public void registrarSede(String nombre, String direccion, int capacidadMaxima, int asientosPorFila,
			int cantidadPuestos, double precioConsumicion, String[] sectores, int[] capacidad,
			int[] porcentajeAdicional) {
		verificarSede(nombre);
		Sedes.put(nombre,new Miniestadio(nombre,direccion, capacidadMaxima, asientosPorFila,
				 cantidadPuestos,  precioConsumicion, sectores,capacidad,porcentajeAdicional));

	}
   private void verificarSede(String sede) {
	   if(Sedes.containsKey(sede)) {throw new RuntimeException("Sede ya registrada");}	
   }

	@Override
	public void registrarUsuario(String email, String nombre, String apellido, String contrasenia) {
		verificarUsuario(email);
		Usuarios.put(email,new Usuario(email,nombre,apellido,contrasenia));
    
	}
	 private void verificarUsuario(String email) {
		 if(Usuarios.containsKey(email)) {throw new RuntimeException("El email esta registrado");}
	  }
	@Override
	public void registrarEspectaculo(String nombre) {
    verificarEspectaculo(nombre);
    Espectaculos.put(nombre, new Espectaculo(nombre)); 
}
	private void verificarEspectaculo(String nombre) {
		if (Espectaculos.containsKey(nombre)) {throw new RuntimeException("El espectáculo ya está registrado");}
	    }
	
	@Override
	public void agregarFuncion(String nombreEspectaculo, String fecha, String sede, double precioBase) {
		verificarFuncion(nombreEspectaculo);
		Sede esSede = existeSede(sede);
		Fecha fechaval = new Fecha(fecha);
		Espectaculos.get(nombreEspectaculo).agregarFuncion(new Funcion(nombreEspectaculo,fechaval,esSede,precioBase), fecha);
		}
	

	

	private void verificarFuncion(String nombre) {
		if(!Espectaculos.containsKey(nombre)) {throw new RuntimeException("El espectaculo o la sede no estan registrados"); //////////////////////////////////////////////REVISAR		
		}
	}
	
	
    /**
     * 4) Vende una o varias entradas a un usuario para funciones
     * en sedes no numeradas
     * 
     * Devuelve una lista con las entradas vendidas (Ver interfaz IEntrada).
     *  
     */
	//vender entrada estadio
	@Override
	public List<IEntrada> venderEntrada(String nombreEspectaculo, String fecha, String email, String contrasenia,
			int cantidadEntradas) {
		List<IEntrada> listaEntradasCompradas = new ArrayList<>();
		//si el usuario no está registrado y si la contraseña no es valida
		Usuario comprador= usuarioRegistrado(email, contrasenia);
		//si el espectaculo no está registrado
		if(!Espectaculos.containsKey(nombreEspectaculo)) {throw new RuntimeException("El espectaculo no esta registrado");}
		//Si la sede de la funcion está numerada
		//if(!Espectaculos.get(nombreEspectaculo).(nombreEspectaculo)) {throw new RuntimeException("La sede esta enumerada");}
		//DA ERROR por eso lo comento(lo de arriba)
		if(!Espectaculos.get(nombreEspectaculo).existeFuncionEnestaFecha(fecha)) {throw new RuntimeException("No exite funcion en la fecha"); }
		
		if(Espectaculos.get(nombreEspectaculo).estaFuncionEsNumerada(fecha)){ throw new RuntimeException("La sede de la funcion es numerada");}
		
		for(int i=0;i<cantidadEntradas;i++) {
			Entrada entrada = new Entrada( nombreEspectaculo,  fecha,0, "1234", "campo",
					2, 2,Espectaculos.get(nombreEspectaculo).funciones.get(fecha));
		
			listaEntradasCompradas.add(entrada);
		}
		
		
		return listaEntradasCompradas ;	
					
	}
  //  *  - si el usuario no está registrado......si la contraseña no es valida
//esto lo voy a poner en la ccclase usuario
	

	public Usuario usuarioRegistrado(String email, String contrasenia) {
		if(!Usuarios.containsKey(email)) {throw new RuntimeException("usuario no registrado");}
		Usuario usuario = Usuarios.get(email);
		if(!Usuarios.get(email).validacionContrasenia(contrasenia)) {throw new RuntimeException("contrasenia invalida");}
		
		return usuario;		
	  }
	
	//verifica que si el email no este registrado y si la contra es correcta
	//private void verificoUser(String email, String contrasenia) {
		//if(!Usuarios.containsKey(email)) {throw new RuntimeException("El email no esta registrado");}
		//else {
			//if(Usuarios.get(contrasenia).validacionContrasenia(contrasenia)) {     //corroborar..............................................
			  //return Usuarios.get(email);
			//}
			
		//}
		//throw new RuntimeException("contrasenia invalida");
			
	//}
	
	
	
	

   //vender Entrada teatro
//	@Override
//	public List<IEntrada> venderEntrada(String nombreEspectaculo, String fecha, String email, String contrasenia,
//			String sector, int[] asientos) {
//				return null;
//		
		
		
		
		
	
//CODIGO DE NICO................................................................................................................
	//vender Entrada teatro
	@Override
	public List<IEntrada> venderEntrada(String nombreEspectaculo, String fecha, String email, String contrasenia,
			String sector, int[] asientos) {
		List<IEntrada> listaEntradasCompradas = new ArrayList<>();
		
		// TODO Auto-generated method stub
		if(!Espectaculos.containsKey(nombreEspectaculo)) {throw new RuntimeException("El espectaculo no ha sido registrado");}
		if(!Usuarios.containsKey(email)) {throw new RuntimeException("El usuario no ha sido registrado");}
		Usuario u = Usuarios.get(email);
		if (!u.validacionContrasenia(contrasenia)) throw new RuntimeException("Contra invalida");
		for(int i=0;i<asientos.length;i++) {
			Entrada entrada = new Entrada( nombreEspectaculo,  fecha,0, "1234", "campo",
					2, 2,Espectaculos.get(nombreEspectaculo).funciones.get(fecha));
		
			listaEntradasCompradas.add(entrada);
		}
		return listaEntradasCompradas;
	}

	/**
     * 5) Devuelve un string donde cada fila representa una funcion 
     * y se detalla con el siguiente formato:
     * 	- Si es estadio: " - ({FECHA}) {NOMBRE SEDE} - {ENTRADAS VENDIDAS} / {CAPACIDAD SEDE}"
     *  - si no es estadio: " - ({FECHA}) {NOMBRE SEDE} - {NOMBRE SECTOR1}: {ENTRADAS VENDIDAS 1} / {CAPACIDAD SECTOR} | {NOMBRE SECTOR 2}: {ENTRADAS VENDIDAS 2} / {CAPACIDAD SECTOR 2} ..."
     * 
     * Por ejemplo:
     *  - (24/07/2025) El Monumental - 200/500
     *  - (31/07/2025) Teatro Colón - Platea VIP: 30/50 | Platea Común: 60/70 | Platea Baja: 0/70 | Platea Alta: 50/50
     * 
     * @return un string con la lista de funciones del espectaculo.
     */
	
	@Override
	public String listarFunciones(String nombreEspectaculo) {
		String funcionRepres = Espectaculos.get(nombreEspectaculo).listarFunciones();	
		System.out.println(funcionRepres);
		
		return funcionRepres;
		
		
	}
	

	@Override
	public List<IEntrada> listarEntradasEspectaculo(String nombreEspectaculo) {
		
		
		return null;
	}

	@Override
	public List<IEntrada> listarEntradasFuturas(String email, String contrasenia) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<IEntrada> listarTodasLasEntradasDelUsuario(String email, String contrasenia) {
		// TODO Auto-generated method stub
		return null;
	}
    
    /**
     * 8) Cancela una entrada comprada por el usuario. Se debe resolver en O(1)
     * 
     * Al cancelarla, el lugar asignado deberá volver a estar disponible.
     * 
     * Se deben validar los datos y lanzar una excepcion en caso de que 
     * algo sea invalido.
     * 
     * Si los datos son validos pero la fecha de la entrada ya pasó,
     * se debe devolver falso
     * 
     * Ver interfaz IEntrada.
     * 
     * 
     * @param Entrada
     * @param contrasenia
     * @return
     *  
     */
	@Override
	public boolean anularEntrada(IEntrada entrada, String contrasenia) {
	
		return false;
	}

	@Override
	public IEntrada cambiarEntrada(IEntrada entrada, String contrasenia, String fecha, String sector, int asiento) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public IEntrada cambiarEntrada(IEntrada entrada, String contrasenia, String fecha) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double costoEntrada(String nombreEspectaculo, String fecha) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double costoEntrada(String nombreEspectaculo, String fecha, String sector) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double totalRecaudado(String nombreEspectaculo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double totalRecaudadoPorSede(String nombreEspectaculo, String nombreSede) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
	private Sede existeSede(String sede) {
			if(Sedes.containsKey(sede)){
				return Sedes.get(sede);
			}else
				throw new RuntimeException("La sede:"+ sede+" no esta cargada en el sistema");
			
		
	}
	
}
