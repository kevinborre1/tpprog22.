package tp;

public class Sector {

	  private String nombre;
	    private int asientosPorFila;
	    private int aumentoPrecio;
	    private int asientosUltFila;
	    private int capacidadMaxima;    
	    
	  
	  
		public Sector(int asientosPorFila, String nombre, int capacidad, int aumentoPrecio) {
			super();
			this.asientosPorFila = asientosPorFila;
			this.capacidadMaxima = capacidad;
			this.aumentoPrecio = aumentoPrecio;	
			this.nombre = nombre;
			;
		}
	
		

		public Sector(String nombre, int capacidadMaxima, int aumentoPrecio) {
			super();
			this.nombre = nombre;
			this.aumentoPrecio = aumentoPrecio;
			this.capacidadMaxima = capacidadMaxima;
		}




		public int cualEsMiCapacidad() {
			return this.capacidadMaxima;
		}


		public String getNombre() {
			return nombre;
		}


		public String formatoFuncion(Integer vendida) {
			StringBuilder st=new StringBuilder();
			st.append(" ");
			st.append(this.nombre);
			st.append(": ");
			st.append(vendida);
			st.append("/");
			st.append(this.capacidadMaxima);
			st.append(" |");
			return st.toString();
		}

	
		
		
		
}
