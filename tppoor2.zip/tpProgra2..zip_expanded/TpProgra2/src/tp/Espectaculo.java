package tp;
import java.util.HashMap;
import java.util.Map;
import tp.Funcion; 


//entonces quedó que un espectáculo tiene una única funcion por fecha 
//y esta puede ser en cualquier sede, incluso repetir sede en distintos días.
public class Espectaculo {
	String nombreEspectaculo;

	HashMap<String, Funcion> funciones;	
	

	public Espectaculo(String nombreEspectaculo) {
		this.nombreEspectaculo = nombreEspectaculo;
		this.funciones= new HashMap<>();
	}
	
	
	public void agregarFuncion(Funcion f, String fecha) {
		if(!funciones.containsKey(fecha)) {
			funciones.put(fecha, f);
		} else{
		throw new RuntimeException ("Fecha repetida del mismo espectaculo");
	}
	}

  
	
	public boolean estaFuncionEsNumerada(String fecha) {
		if(funciones.containsKey(fecha))
			return funciones.get(fecha).laSedeEsnumerada();
		
		
		return false;
	}

public Funcion getFuncionPorFecha(String fecha) {
	// TODO Auto-generated method stub
	return null;
}


public boolean existeFuncionEnestaFecha(String fecha) {
	if(funciones.containsKey(fecha)) {
		return true;
	}
	return false;
}


	public String listarFunciones() {
		StringBuilder listado = new StringBuilder();
		for(Funcion funcion: this.funciones.values()) {
			listado.append(funcion.toString());
		}
		return listado.toString();
	}

	@Override
	public String toString() {
		StringBuilder espectaculo = new StringBuilder();
		espectaculo.append(this.nombreEspectaculo);
		espectaculo.append(" tiene las Funciones\n");
		espectaculo.append(listarFunciones());
		return espectaculo.toString();
		
	}
}



