package tp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public abstract class Sede {
	protected String nombre;
	protected String direccion; 
	protected int capacidadMaxima;
	 public ArrayList<Sector> sectores; 
//	int asientosPorFila; 
//	int cantidadPuestos; 
//	double precioConsumicion; //CLASE HIJA LOS TIENEN 
//	int[] capacidad;
//	int[] porcentajeAdicional;
	
	public Sede(String nombre, String direccion, int capacidadMaxima) {
		super();
		this.nombre = nombre;
		this.direccion = direccion;
		this.capacidadMaxima = capacidadMaxima;
		this.sectores = new ArrayList<>();
	}
  
//Si es un estadio return false
	//si no return true
	public abstract boolean esNumerada();

	public abstract String formatoFuncion(ArrayList<Integer> cantidadVendida) ;

	public  ArrayList<String> Sectores(){
		ArrayList<String> sectores = new ArrayList<>();
		for(Sector sector:this.sectores) {
			sectores.add(sector.getNombre());
		}
		return sectores;
	}
    
    
    public String getNombre() {
    	return this.nombre;
    }

    public int espacioDelSector(String nombreSector) {
        for (Sector s : this.sectores) {
            if (s.getNombre().equals(nombreSector)) {
                return s.cualEsMiCapacidad();
            }
        }
        throw new IllegalArgumentException("No existe el sector llamado " + nombreSector + " en la sede " + this.nombre);
    }
    
    @Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sede other = (Sede) obj;
		return capacidadMaxima == other.capacidadMaxima && Objects.equals(direccion, other.direccion)
				&& Objects.equals(nombre, other.nombre) && Objects.equals(sectores, other.sectores);
	}
    
    
    
    
    public String formatoFuncion(Integer vendida) {
		StringBuilder st=new StringBuilder();
		st.append(" ");
		st.append(this.nombre);
		st.append(": ");
		st.append(vendida);
		st.append("/");
		st.append(this.capacidadMaxima);
		st.append(" |");
		return st.toString();
	}

}

