package tp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class Funcion {
	 String nombreEspectaculo;
	 Fecha fecha;
	 Sede sede;	 
	 double precioBase;
	 HashMap<String, Sede> Sedes;
	 private HashMap<String, ArrayList<IEntrada>> entradasPorSectorVendidas;
	
	 
	 public Funcion(String nombreEspectaculo, Fecha fecha, Sede sede, double precioBase) {
		this.nombreEspectaculo= nombreEspectaculo;
		this.fecha = fecha;
		this.sede = sede;
		this.precioBase = precioBase;
		this.entradasPorSectorVendidas = new HashMap<>();
		for (String sector : this.sede.Sectores()) {
			this.entradasPorSectorVendidas.put
			(sector, new ArrayList<IEntrada>(Collections.nCopies(this.sede.espacioDelSector(sector), null)));
		}
	 }

//	 private static Fecha parsearFecha(String fechaStr) {
//		    // formato esperado: "dd/MM/yyyy"
//		    String[] partes = fechaStr.split("/");
//		    int dia = Integer.parseInt(partes[0]);
//		    int mes = Integer.parseInt(partes[1]);
//		    int anio = Integer.parseInt(partes[2]);
//		    return new Fecha(dia, mes, anio);
//		}
	 
	 
	 
	public double getPrecioBase() {
		return precioBase;
	}

	public void setPrecioBase(double precioBase) {
		this.precioBase = precioBase;
	}

	public Sede getSede() {
		return sede;
	}

	public Sede setSede(Sede sede) {
		return this.sede = sede;
	}

	public void registrarEntradaVendida(Entrada entrada) {
		// TODO Auto-generated method stub
		
	}

	public boolean laSedeEsnumerada() {
		
		return this.sede.esNumerada();
	}

	public String getFecha() {
	    return fecha.toString(); // Usa el toString() de la clase Fecha 
	}



	
		

	public int ocupados(String sector) {
	    ArrayList<IEntrada> entradas = entradasPorSectorVendidas.getOrDefault(sector, new ArrayList<>());
	    int contador = 0;
	    for (IEntrada e : entradas) {
	        if (e != null) contador++;
	    }
	    return contador;
	}

	 
	public int total(String sector) {
	    return this.sede.espacioDelSector(sector);
	}

//	@Override
//	public String toString() {
//		StringBuilder funcion= new StringBuilder();
//		funcion.append(" - (");
//		funcion.append(this.fecha.toString());
//		funcion.append(") ");
//		ArrayList<Integer> cantidadVendida= new ArrayList<Integer>();
//		for(String sector : this.sede.Sectores()){
//			cantidadVendida.add(cantidadVendidadEn(sector));
//		}
//		funcion.append(this.sede.formatoFuncion(cantidadVendida));		
//		funcion.append("\n");		
//		return funcion.toString();
//	}
//	private Integer cantidadVendidadEn(String sector) {
//		if (!this.entradasPorSectorVendidas.containsKey(sector)) {
//		    this.entradasPorSectorVendidas.put(sector, new ArrayList<>());
//		}
//		int vendidas =0;
//		List<IEntrada> entradas = this.entradasPorSectorVendidas.get(sector);
//		for(IEntrada seVendio:entradas)
//			if(seVendio!=null) {
//				vendidas++;
//			}
//		
//		return vendidas;
//	}
//	




}
	
	
	
	
	

