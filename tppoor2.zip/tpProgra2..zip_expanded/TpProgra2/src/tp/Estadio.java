package tp;

import java.util.ArrayList;

public class Estadio extends Sede {
	
	public Estadio(String nombre, String direccion, int capacidadMaxima) {
		super(nombre, direccion, capacidadMaxima);
		this.sectores.add(new Sector("CAMPO",0,capacidadMaxima));
	}

	
	
	@Override
	public boolean esNumerada() {
		return false;
	}
	
	
	
	
	@Override
	public String formatoFuncion(ArrayList<Integer> cantidadVendida) {
		StringBuilder st=new StringBuilder(this.nombre);
		
		st.append(" - ");
		st.append(cantidadVendida.get(0));
		st.append("/");
		st.append(this.capacidadMaxima);
		return st.toString();		
	}


	// revisar 
//	@Override
//	public String toString() {
//	    StringBuilder sb = new StringBuilder();
//	    sb.append("(")
//	      .append(fecha)
//	      .append(") ")
//	      .append(nombre)
//	      .append(" - ")
//	      .append(entradasVendidas)
//	      .append(" / ")
//	      .append(capacidad);
//
//	    return sb.toString();
//	}
//
}
