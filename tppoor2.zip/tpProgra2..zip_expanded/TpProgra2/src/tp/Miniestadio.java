package tp;

import java.util.ArrayList;

public class Miniestadio extends Sede {

	private int cantidadPuestos;
    private int cantidadPuestosComida;
    private double precioConsumicion;

	
	
	
	
	public Miniestadio(String nombre,String direccion,int capacidadMaxima, int asientosPorFila, int cantidadPuestos, double precioConsumicion,
                       String[] sectores, int[] capacidad,int[] porcentajeAdicional) {
		super(direccion, nombre,capacidadMaxima);
		
		this.cantidadPuestos = cantidadPuestos;
		this.precioConsumicion = precioConsumicion;
		for(int i =0; i< sectores.length;i++) {
			this.sectores.add(new Sector(asientosPorFila,sectores[i],capacidad[i],porcentajeAdicional[i]));	
		}
	}





	@Override
	public boolean esNumerada() {

		return true;
	}





	@Override
	public String formatoFuncion(ArrayList<Integer> cantidadVendida) {
		StringBuilder st=new StringBuilder(this.nombre);
		System.out.println("aca esta el problema"+this.nombre);
		st.append(" -");
		for(int i=0 ;i<this.sectores.size();i++) {
			st.append(this.sectores.get(i).formatoFuncion(cantidadVendida.get(i)));
		}
		st.setLength(st.length()-2);
		
		return st.toString();
		
	}





	









}



