package tp;
import tp.Funcion;

public class Entrada implements IEntrada  {
	String nombreEspectaculo;
	String fecha;
	int cantidadEntradas;
	String codigo;
	String ubicacion;
    int fila;
    int asiento;
    Funcion funcion;


    
 public Entrada(String nombreEspectaculo, String fecha, int cantidadEntradas, String codigo, String ubicacion,
			int fila, int asiento, Funcion funcion) {
		super();
		this.nombreEspectaculo = nombreEspectaculo;
		this.fecha = fecha;
		this.cantidadEntradas = cantidadEntradas;
		this.codigo = codigo;
		this.ubicacion = ubicacion;
		this.fila = fila;
		this.asiento = asiento;
		this.funcion = funcion;
	}


public Entrada(Funcion funcion2, Usuario comprador) {
	// TODO Auto-generated constructor stub
}


@Override
public double precio() {
	//if(ubicacion== "CAMPO" || ubicacion=="alta") {//es un estadio 
	//	return funcion.getPrecioBase();
	//}                                                                           //NO VA ESTO PERO LO DEJO POR LAS DUDAS, A LO ULTIMO LO BORRAMOS
	if(ubicacion=="Comun") {
		return funcion.getPrecioBase() +(funcion.getPrecioBase()* 0.4); //precio platea comun + 40%
	}
	if (ubicacion=="VIP") {
		return funcion.getPrecioBase() +(funcion.getPrecioBase()* 0.7); //precio platea VIP + 70%	
	}
	if(ubicacion== "Baja") {
		return funcion.getPrecioBase() +(funcion.getPrecioBase()* 0.5); //precio platea baja + 50%
	}
	return funcion.getPrecioBase();  //si no es ni platea baja, comun o VIP, es campo o platea baja. Por lo tanto no se le agrega nada al precioBase
	
}

@Override
public String ubicacion() {
	
	
	
	return null;
}

//FALTA EL TEMA DE LA FECHA 
@Override
public String toString() {
	Sede sede= funcion.getSede();
	if(ubicacion == "CAMPO" ) {
	   return "- " + codigo + " - " + nombreEspectaculo + " - " + fecha + " - "  + sede + " - " + ubicacion ;
	}
	return "- " + codigo + " - " + nombreEspectaculo + " - " + fecha + " - "  + sede + " - " + ubicacion + " f:" +fila + " a:"+asiento ;
}


public void liberarLugar() {
	// TODO Auto-generated method stub
	
}

}
